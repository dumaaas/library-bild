<!-- Notification for small devices -->
<div class="py-[20px] hidden small:block bg-gradient-to-r  from-red-500 mt-[100px]">
    <h1 class="text-[40px] font-medium text-center text-white">
        Trenutno nedostupno...
    </h1>
    <p class="text-[17px] text-white text-center">
        Molimo Vas da koristite vecu rezoluciju.
    </p>
</div>